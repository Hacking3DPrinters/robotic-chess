# robotic-chess
An AI-powered chess playing robot, powered by Raspberry Pi.
